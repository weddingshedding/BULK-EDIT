'use strict';

const MAX_FILES = 1000;
const DEFAULTS = Object.freeze({
  width: 400,
  height: 400,
  targetKb: 100,
  format: 'image/jpeg',
  fit: 'contain',
  background: '#FFFFFF',
  transparent: false,
  prefix: 'optimized-'
});

const state = {
  items: [],
  processing: false,
  currentEditId: null,
  editorDraft: null,
  editorImage: null,
  results: [],
  resultUrls: [],
  zipBlob: null,
  originalRatio: DEFAULTS.width / DEFAULTS.height
};

const $ = (id) => document.getElementById(id);
const els = {
  fileInput: $('fileInput'), folderInput: $('folderInput'), choosePhotosBtn: $('choosePhotosBtn'), chooseFolderBtn: $('chooseFolderBtn'), dropZone: $('dropZone'),
  widthInput: $('widthInput'), heightInput: $('heightInput'), targetKbInput: $('targetKbInput'), formatSelect: $('formatSelect'), fitSelect: $('fitSelect'),
  backgroundColorInput: $('backgroundColorInput'), backgroundHexInput: $('backgroundHexInput'), transparentInput: $('transparentInput'), filenamePrefixInput: $('filenamePrefixInput'), lockRatioInput: $('lockRatioInput'), resetSettingsBtn: $('resetSettingsBtn'),
  queueCard: $('queueCard'), processCard: $('processCard'), queueSummary: $('queueSummary'), photoGrid: $('photoGrid'), searchInput: $('searchInput'),
  selectAllBtn: $('selectAllBtn'), removeSelectedBtn: $('removeSelectedBtn'), clearAllBtn: $('clearAllBtn'), processBtn: $('processBtn'),
  progressArea: $('progressArea'), progressText: $('progressText'), progressPercent: $('progressPercent'), progressBar: $('progressBar'), successCount: $('successCount'), errorCount: $('errorCount'), sizeSavedText: $('sizeSavedText'),
  resultActions: $('resultActions'), downloadZipBtn: $('downloadZipBtn'), downloadIndividualBtn: $('downloadIndividualBtn'), errorList: $('errorList'),
  editorModal: $('editorModal'), editorTitle: $('editorTitle'), closeEditorBtn: $('closeEditorBtn'), cancelEditBtn: $('cancelEditBtn'), saveEditBtn: $('saveEditBtn'), resetEditBtn: $('resetEditBtn'), editorCanvas: $('editorCanvas'), canvasLoading: $('canvasLoading'),
  rotateLeftBtn: $('rotateLeftBtn'), rotateRightBtn: $('rotateRightBtn'), flipHBtn: $('flipHBtn'), flipVBtn: $('flipVBtn'), zoomRange: $('zoomRange'), panXRange: $('panXRange'), panYRange: $('panYRange'), brightnessRange: $('brightnessRange'), contrastRange: $('contrastRange'), saturationRange: $('saturationRange'), grayscaleRange: $('grayscaleRange'), blurRange: $('blurRange'), sharpnessRange: $('sharpnessRange'),
  zoomOutput: $('zoomOutput'), panXOutput: $('panXOutput'), panYOutput: $('panYOutput'), brightnessOutput: $('brightnessOutput'), contrastOutput: $('contrastOutput'), saturationOutput: $('saturationOutput'), grayscaleOutput: $('grayscaleOutput'), blurOutput: $('blurOutput'), sharpnessOutput: $('sharpnessOutput'),
  useCustomOutputInput: $('useCustomOutputInput'), customWidthInput: $('customWidthInput'), customHeightInput: $('customHeightInput'), customKbInput: $('customKbInput'), toastRegion: $('toastRegion')
};

function uid() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, Number(value) || 0));
}

function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 KB';
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(bytes < 10240 ? 1 : 0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function safeBaseName(name) {
  const base = String(name || 'photo').replace(/\.[^.]+$/, '');
  return base.replace(/[<>:"/\\|?*\x00-\x1F]/g, '-').replace(/\s+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '') || 'photo';
}

function extensionFor(mime) {
  if (mime === 'image/webp') return 'webp';
  if (mime === 'image/png') return 'png';
  return 'jpg';
}

function defaultEdit() {
  return {
    rotation: 0,
    flipH: 1,
    flipV: 1,
    zoom: 1,
    panX: 0,
    panY: 0,
    brightness: 100,
    contrast: 100,
    saturation: 100,
    grayscale: 0,
    blur: 0,
    sharpness: 0,
    useCustomOutput: false,
    customWidth: DEFAULTS.width,
    customHeight: DEFAULTS.height,
    customKb: DEFAULTS.targetKb
  };
}

function isEditDefault(edit) {
  return JSON.stringify(edit) === JSON.stringify(defaultEdit());
}

function showToast(message, type = '') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`.trim();
  toast.textContent = message;
  els.toastRegion.appendChild(toast);
  setTimeout(() => toast.remove(), 3300);
}

function getBulkSettings() {
  const width = clamp(els.widthInput.value, 1, 8000);
  const height = clamp(els.heightInput.value, 1, 8000);
  const targetKb = clamp(els.targetKbInput.value, 5, 5000);
  return {
    width,
    height,
    targetKb,
    format: els.formatSelect.value,
    fit: els.fitSelect.value,
    background: /^#[0-9a-f]{6}$/i.test(els.backgroundHexInput.value.trim()) ? els.backgroundHexInput.value.trim().toUpperCase() : els.backgroundColorInput.value.toUpperCase(),
    transparent: els.transparentInput.checked && els.formatSelect.value === 'image/png',
    prefix: els.filenamePrefixInput.value.trim()
  };
}

function resetBulkSettings() {
  els.widthInput.value = DEFAULTS.width;
  els.heightInput.value = DEFAULTS.height;
  els.targetKbInput.value = DEFAULTS.targetKb;
  els.formatSelect.value = DEFAULTS.format;
  els.fitSelect.value = DEFAULTS.fit;
  els.backgroundColorInput.value = DEFAULTS.background.toLowerCase();
  els.backgroundHexInput.value = DEFAULTS.background;
  els.transparentInput.checked = DEFAULTS.transparent;
  els.filenamePrefixInput.value = DEFAULTS.prefix;
  els.lockRatioInput.checked = false;
  state.originalRatio = 1;
  updateFormatState();
  showToast('Bulk settings reset to 400×400 px and 100 KB.', 'success');
}

function updateFormatState() {
  const isPng = els.formatSelect.value === 'image/png';
  els.transparentInput.disabled = !isPng;
  if (!isPng) els.transparentInput.checked = false;
}

function syncColorFromPicker() {
  els.backgroundHexInput.value = els.backgroundColorInput.value.toUpperCase();
}

function syncColorFromHex() {
  const value = els.backgroundHexInput.value.trim();
  if (/^#[0-9a-f]{6}$/i.test(value)) els.backgroundColorInput.value = value;
}

function imageFilesFromList(fileList) {
  return Array.from(fileList || []).filter((file) => file.type.startsWith('image/'));
}

async function addFiles(fileList) {
  if (state.processing) return;
  const incoming = imageFilesFromList(fileList);
  if (!incoming.length) {
    showToast('No supported image files found.', 'error');
    return;
  }

  const remaining = Math.max(0, MAX_FILES - state.items.length);
  const accepted = incoming.slice(0, remaining);
  if (!remaining) {
    showToast(`Maximum ${MAX_FILES} photos allowed in one batch.`, 'error');
    return;
  }

  const known = new Set(state.items.map((item) => `${item.file.name}|${item.file.size}|${item.file.lastModified}`));
  let added = 0;
  for (const file of accepted) {
    const signature = `${file.name}|${file.size}|${file.lastModified}`;
    if (known.has(signature)) continue;
    known.add(signature);
    const previewUrl = URL.createObjectURL(file);
    state.items.push({ id: uid(), file, previewUrl, selected: false, edit: defaultEdit(), width: null, height: null });
    added += 1;
  }

  if (incoming.length > accepted.length) showToast(`Only first ${remaining} photos were added. Batch limit is ${MAX_FILES}.`, 'error');
  if (!added) {
    showToast('These photos are already in the queue.', 'error');
    return;
  }

  clearResults();
  renderQueue();
  showToast(`${added} photo${added === 1 ? '' : 's'} added.`, 'success');
  hydrateDimensions(state.items.slice(-added));
}

async function hydrateDimensions(items) {
  for (const item of items) {
    try {
      const img = await loadImage(item.file);
      item.width = img.naturalWidth || img.width;
      item.height = img.naturalHeight || img.height;
    } catch { /* shown only during processing */ }
  }
  renderQueue();
}

function renderQueue() {
  const hasItems = state.items.length > 0;
  els.queueCard.classList.toggle('is-hidden', !hasItems);
  els.processCard.classList.toggle('is-hidden', !hasItems);
  els.queueSummary.textContent = `${state.items.length} photo${state.items.length === 1 ? '' : 's'} selected • ${formatBytes(state.items.reduce((sum, item) => sum + item.file.size, 0))}`;

  const filter = els.searchInput.value.trim().toLowerCase();
  const filtered = state.items.filter((item) => item.file.name.toLowerCase().includes(filter));
  els.photoGrid.innerHTML = '';

  if (!filtered.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.textContent = hasItems ? 'No filename matched your search.' : 'No photos added yet.';
    els.photoGrid.appendChild(empty);
    return;
  }

  const fragment = document.createDocumentFragment();
  for (const item of filtered) {
    const card = document.createElement('article');
    card.className = 'photo-card';
    card.dataset.id = item.id;
    const dimensions = item.width && item.height ? `${item.width}×${item.height}` : 'Reading...';
    card.innerHTML = `
      <input class="photo-select" type="checkbox" ${item.selected ? 'checked' : ''} aria-label="Select ${escapeHtml(item.file.name)}">
      ${!isEditDefault(item.edit) ? '<span class="edit-badge">MANUAL EDIT</span>' : ''}
      <div class="photo-thumb-wrap"><img src="${item.previewUrl}" alt="${escapeHtml(item.file.name)}" loading="lazy"></div>
      <div class="photo-info">
        <p class="photo-name" title="${escapeHtml(item.file.name)}">${escapeHtml(item.file.name)}</p>
        <div class="photo-meta"><span>${dimensions}</span><span>${formatBytes(item.file.size)}</span></div>
        <div class="photo-actions"><button class="edit-one" type="button">Manual Edit</button><button class="remove-one" type="button">Remove</button></div>
      </div>`;
    fragment.appendChild(card);
  }
  els.photoGrid.appendChild(fragment);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));
}

function handleGridClick(event) {
  const card = event.target.closest('.photo-card');
  if (!card) return;
  const item = state.items.find((entry) => entry.id === card.dataset.id);
  if (!item) return;
  if (event.target.classList.contains('edit-one')) openEditor(item.id);
  if (event.target.classList.contains('remove-one')) removeItem(item.id);
}

function handleGridChange(event) {
  if (!event.target.classList.contains('photo-select')) return;
  const card = event.target.closest('.photo-card');
  const item = state.items.find((entry) => entry.id === card?.dataset.id);
  if (item) item.selected = event.target.checked;
}

function removeItem(id) {
  const index = state.items.findIndex((item) => item.id === id);
  if (index < 0) return;
  URL.revokeObjectURL(state.items[index].previewUrl);
  state.items.splice(index, 1);
  clearResults();
  renderQueue();
}

function removeSelected() {
  const selected = state.items.filter((item) => item.selected);
  if (!selected.length) {
    showToast('Select photos first.', 'error');
    return;
  }
  const ids = new Set(selected.map((item) => item.id));
  selected.forEach((item) => URL.revokeObjectURL(item.previewUrl));
  state.items = state.items.filter((item) => !ids.has(item.id));
  clearResults();
  renderQueue();
  showToast(`${selected.length} selected photo${selected.length === 1 ? '' : 's'} removed.`);
}

function clearAll() {
  state.items.forEach((item) => URL.revokeObjectURL(item.previewUrl));
  state.items = [];
  clearResults();
  renderQueue();
  els.fileInput.value = '';
  els.folderInput.value = '';
}

function toggleSelectAll() {
  const allSelected = state.items.length > 0 && state.items.every((item) => item.selected);
  state.items.forEach((item) => { item.selected = !allSelected; });
  els.selectAllBtn.textContent = allSelected ? 'Select all' : 'Unselect all';
  renderQueue();
}

function loadImage(fileOrBlob) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(fileOrBlob);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Image could not be decoded.')); };
    img.src = url;
  });
}

function getItemOutputSettings(item, bulk) {
  if (item.edit.useCustomOutput) {
    return { ...bulk, width: clamp(item.edit.customWidth, 1, 8000), height: clamp(item.edit.customHeight, 1, 8000), targetKb: clamp(item.edit.customKb, 5, 5000) };
  }
  return bulk;
}

function drawTransformedImage(ctx, img, width, height, fit, background, transparent, edit) {
  ctx.save();
  ctx.clearRect(0, 0, width, height);
  if (!transparent) {
    ctx.fillStyle = background;
    ctx.fillRect(0, 0, width, height);
  }

  const rotation = ((edit.rotation % 360) + 360) % 360;
  const quarterTurn = rotation === 90 || rotation === 270;
  const sourceW = quarterTurn ? img.naturalHeight : img.naturalWidth;
  const sourceH = quarterTurn ? img.naturalWidth : img.naturalHeight;

  let scaleX = width / sourceW;
  let scaleY = height / sourceH;
  if (fit === 'contain') scaleX = scaleY = Math.min(scaleX, scaleY);
  if (fit === 'cover') scaleX = scaleY = Math.max(scaleX, scaleY);
  if (fit !== 'stretch') {
    scaleX *= edit.zoom;
    scaleY *= edit.zoom;
  } else {
    scaleX *= edit.zoom;
    scaleY *= edit.zoom;
  }

  ctx.translate(width / 2 + (edit.panX / 100) * width, height / 2 + (edit.panY / 100) * height);
  ctx.rotate(rotation * Math.PI / 180);
  ctx.scale(scaleX * edit.flipH, scaleY * edit.flipV);
  ctx.filter = `brightness(${edit.brightness}%) contrast(${edit.contrast}%) saturate(${edit.saturation}%) grayscale(${edit.grayscale}%) blur(${edit.blur}px)`;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, -img.naturalWidth / 2, -img.naturalHeight / 2);
  ctx.restore();

  if (edit.sharpness > 0) applySharpen(ctx, width, height, edit.sharpness);
}

function applySharpen(ctx, width, height, amount) {
  if (width * height > 4_000_000) return;
  const strength = clamp(amount, 0, 5) * 0.12;
  const imageData = ctx.getImageData(0, 0, width, height);
  const src = imageData.data;
  const out = new Uint8ClampedArray(src);
  const row = width * 4;
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const i = y * row + x * 4;
      for (let c = 0; c < 3; c++) {
        const center = src[i + c];
        const lap = center * 4 - src[i - 4 + c] - src[i + 4 + c] - src[i - row + c] - src[i + row + c];
        out[i + c] = clamp(center + lap * strength, 0, 255);
      }
    }
  }
  imageData.data.set(out);
  ctx.putImageData(imageData, 0, 0);
}

function canvasToBlob(canvas, mime, quality) {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error('Browser could not export this image.')), mime, quality);
  });
}

async function exportUnderTarget(canvas, mime, targetBytes) {
  if (mime === 'image/png') {
    const blob = await canvasToBlob(canvas, mime);
    return { blob, quality: null, targetReached: blob.size <= targetBytes };
  }

  let low = 0.05;
  let high = 0.95;
  let best = null;
  let bestQuality = low;
  const minimum = await canvasToBlob(canvas, mime, low);
  if (minimum.size > targetBytes) return { blob: minimum, quality: low, targetReached: false };

  for (let i = 0; i < 10; i++) {
    const quality = (low + high) / 2;
    const blob = await canvasToBlob(canvas, mime, quality);
    if (blob.size <= targetBytes) {
      best = blob;
      bestQuality = quality;
      low = quality;
    } else {
      high = quality;
    }
  }
  return { blob: best || minimum, quality: bestQuality, targetReached: true };
}

const CRC32_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(bytes) {
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < bytes.length; i++) crc = CRC32_TABLE[(crc ^ bytes[i]) & 0xFF] ^ (crc >>> 8);
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function toDosDateTime(date = new Date()) {
  const year = Math.max(1980, date.getFullYear());
  const dosTime = ((date.getHours() & 0x1F) << 11) | ((date.getMinutes() & 0x3F) << 5) | Math.floor(date.getSeconds() / 2);
  const dosDate = (((year - 1980) & 0x7F) << 9) | (((date.getMonth() + 1) & 0x0F) << 5) | (date.getDate() & 0x1F);
  return { dosTime, dosDate };
}

async function createStoredZip(entries, onProgress = () => {}) {
  const encoder = new TextEncoder();
  const localParts = [];
  const centralParts = [];
  const { dosTime, dosDate } = toDosDateTime();
  let localOffset = 0;
  let centralSize = 0;

  for (let index = 0; index < entries.length; index++) {
    const entry = entries[index];
    const nameBytes = encoder.encode(entry.name);
    const data = new Uint8Array(await entry.blob.arrayBuffer());
    const checksum = crc32(data);

    const localHeader = new Uint8Array(30 + nameBytes.length);
    const localView = new DataView(localHeader.buffer);
    localView.setUint32(0, 0x04034B50, true);
    localView.setUint16(4, 20, true);
    localView.setUint16(6, 0x0800, true);
    localView.setUint16(8, 0, true);
    localView.setUint16(10, dosTime, true);
    localView.setUint16(12, dosDate, true);
    localView.setUint32(14, checksum, true);
    localView.setUint32(18, data.length, true);
    localView.setUint32(22, data.length, true);
    localView.setUint16(26, nameBytes.length, true);
    localView.setUint16(28, 0, true);
    localHeader.set(nameBytes, 30);
    localParts.push(localHeader, data);

    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const centralView = new DataView(centralHeader.buffer);
    centralView.setUint32(0, 0x02014B50, true);
    centralView.setUint16(4, 20, true);
    centralView.setUint16(6, 20, true);
    centralView.setUint16(8, 0x0800, true);
    centralView.setUint16(10, 0, true);
    centralView.setUint16(12, dosTime, true);
    centralView.setUint16(14, dosDate, true);
    centralView.setUint32(16, checksum, true);
    centralView.setUint32(20, data.length, true);
    centralView.setUint32(24, data.length, true);
    centralView.setUint16(28, nameBytes.length, true);
    centralView.setUint16(30, 0, true);
    centralView.setUint16(32, 0, true);
    centralView.setUint16(34, 0, true);
    centralView.setUint16(36, 0, true);
    centralView.setUint32(38, 0, true);
    centralView.setUint32(42, localOffset, true);
    centralHeader.set(nameBytes, 46);
    centralParts.push(centralHeader);

    localOffset += localHeader.length + data.length;
    centralSize += centralHeader.length;
    onProgress(index + 1, entries.length);
    await nextFrame();
  }

  const end = new Uint8Array(22);
  const endView = new DataView(end.buffer);
  endView.setUint32(0, 0x06054B50, true);
  endView.setUint16(4, 0, true);
  endView.setUint16(6, 0, true);
  endView.setUint16(8, entries.length, true);
  endView.setUint16(10, entries.length, true);
  endView.setUint32(12, centralSize, true);
  endView.setUint32(16, localOffset, true);
  endView.setUint16(20, 0, true);

  return new Blob([...localParts, ...centralParts, end], { type: 'application/zip' });
}

async function processItem(item, index, duplicateNames) {
  const bulk = getBulkSettings();
  const settings = getItemOutputSettings(item, bulk);
  const img = await loadImage(item.file);
  const canvas = document.createElement('canvas');
  canvas.width = settings.width;
  canvas.height = settings.height;
  const ctx = canvas.getContext('2d', { willReadFrequently: item.edit.sharpness > 0 });
  if (!ctx) throw new Error('Canvas is not supported by this browser.');

  drawTransformedImage(ctx, img, settings.width, settings.height, settings.fit, settings.background, settings.transparent, item.edit);
  const exported = await exportUnderTarget(canvas, settings.format, settings.targetKb * 1024);
  const base = `${settings.prefix}${safeBaseName(item.file.name)}`;
  let filename = `${base}.${extensionFor(settings.format)}`;
  const count = duplicateNames.get(filename) || 0;
  duplicateNames.set(filename, count + 1);
  if (count > 0) filename = `${base}-${count + 1}.${extensionFor(settings.format)}`;

  return {
    id: item.id,
    index,
    filename,
    blob: exported.blob,
    originalSize: item.file.size,
    outputSize: exported.blob.size,
    targetKb: settings.targetKb,
    targetReached: exported.targetReached,
    width: settings.width,
    height: settings.height
  };
}

async function processAll() {
  if (!state.items.length || state.processing) return;
  state.processing = true;
  clearResults();
  els.processBtn.disabled = true;
  els.progressArea.classList.remove('is-hidden');
  els.resultActions.classList.add('is-hidden');
  els.errorList.classList.add('is-hidden');
  const errors = [];
  const duplicateNames = new Map();
  let originalBytes = 0;
  let outputBytes = 0;

  for (let i = 0; i < state.items.length; i++) {
    const item = state.items[i];
    updateProgress(i, state.items.length, `Processing ${item.file.name}`);
    await nextFrame();
    try {
      const result = await processItem(item, i, duplicateNames);
      state.results.push(result);
      originalBytes += result.originalSize;
      outputBytes += result.outputSize;
    } catch (error) {
      errors.push({ name: item.file.name, message: error?.message || 'Unknown processing error' });
    }
    updateCounters(errors, originalBytes, outputBytes);
  }

  updateProgress(state.items.length, state.items.length, 'Creating ZIP file...');
  try {
    const report = new Blob([buildReport(errors)], { type: 'text/plain;charset=utf-8' });
    const zipEntries = state.results.map((result) => ({ name: result.filename, blob: result.blob }));
    zipEntries.push({ name: 'processing-report.txt', blob: report });
    state.zipBlob = await createStoredZip(zipEntries, (done, total) => {
      els.progressText.textContent = `Creating ZIP • ${Math.round((done / total) * 100)}%`;
    });
  } catch (error) {
    errors.push({ name: 'ZIP', message: error?.message || 'ZIP creation failed' });
  }

  updateProgress(state.items.length, state.items.length, 'Processing complete');
  updateCounters(errors, originalBytes, outputBytes);
  els.processBtn.disabled = false;
  state.processing = false;

  if (state.results.length) els.resultActions.classList.remove('is-hidden');
  if (errors.length) renderErrors(errors);
  const oversized = state.results.filter((result) => !result.targetReached).length;
  if (oversized) showToast(`${oversized} photo${oversized === 1 ? '' : 's'} could not reach target KB at minimum quality.`, 'error');
  else showToast(`${state.results.length} photos processed successfully.`, 'success');
}

function buildReport(errors) {
  const settings = getBulkSettings();
  const lines = [
    'BulkPix Studio Processing Report',
    `Created: ${new Date().toLocaleString()}`,
    `Bulk settings: ${settings.width}x${settings.height}px, max ${settings.targetKb}KB, ${settings.format}, ${settings.fit}`,
    `Processed: ${state.results.length}`,
    `Errors: ${errors.length}`,
    '',
    ...state.results.map((r) => `${r.filename} | ${r.width}x${r.height}px | ${formatBytes(r.outputSize)} | target ${r.targetKb}KB | ${r.targetReached ? 'OK' : 'ABOVE TARGET'}`)
  ];
  if (errors.length) lines.push('', 'Errors:', ...errors.map((e) => `${e.name}: ${e.message}`));
  return lines.join('\n');
}

function updateProgress(done, total, text) {
  const percent = total ? Math.round((done / total) * 100) : 0;
  els.progressText.textContent = text;
  els.progressPercent.textContent = `${percent}%`;
  els.progressBar.style.width = `${percent}%`;
}

function updateCounters(errors, originalBytes, outputBytes) {
  els.successCount.textContent = `${state.results.length} completed`;
  els.errorCount.textContent = `${errors.length} errors`;
  const saved = Math.max(0, originalBytes - outputBytes);
  els.sizeSavedText.textContent = `${formatBytes(saved)} saved`;
}

function renderErrors(errors) {
  els.errorList.classList.remove('is-hidden');
  els.errorList.innerHTML = `<strong>Problems</strong>${errors.map((error) => `<p>${escapeHtml(error.name)}: ${escapeHtml(error.message)}</p>`).join('')}`;
}

function clearResults() {
  state.resultUrls.forEach((url) => URL.revokeObjectURL(url));
  state.resultUrls = [];
  state.results = [];
  state.zipBlob = null;
  els.progressArea.classList.add('is-hidden');
  els.resultActions.classList.add('is-hidden');
  els.errorList.classList.add('is-hidden');
  els.progressBar.style.width = '0%';
  els.progressPercent.textContent = '0%';
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  state.resultUrls.push(url);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => {
    URL.revokeObjectURL(url);
    state.resultUrls = state.resultUrls.filter((item) => item !== url);
  }, 60000);
}

function downloadZip() {
  if (!state.zipBlob) {
    showToast('Process photos first.', 'error');
    return;
  }
  downloadBlob(state.zipBlob, `bulk-pix-${new Date().toISOString().slice(0, 10)}.zip`);
}

async function downloadIndividually() {
  if (!state.results.length) return;
  showToast('Browser may ask permission for multiple downloads.');
  for (const result of state.results) {
    downloadBlob(result.blob, result.filename);
    await new Promise((resolve) => setTimeout(resolve, 180));
  }
}

function nextFrame() {
  return new Promise((resolve) => requestAnimationFrame(() => resolve()));
}

async function openEditor(id) {
  const item = state.items.find((entry) => entry.id === id);
  if (!item) return;
  state.currentEditId = id;
  state.editorDraft = typeof structuredClone === 'function' ? structuredClone(item.edit) : JSON.parse(JSON.stringify(item.edit));
  els.editorTitle.textContent = item.file.name;
  els.editorModal.classList.remove('is-hidden');
  document.body.style.overflow = 'hidden';
  els.canvasLoading.classList.remove('is-hidden');
  syncEditorInputs();
  try {
    state.editorImage = await loadImage(item.file);
    await renderEditorPreview();
  } catch (error) {
    showToast(error.message, 'error');
    closeEditor();
  } finally {
    els.canvasLoading.classList.add('is-hidden');
  }
}

function closeEditor() {
  els.editorModal.classList.add('is-hidden');
  document.body.style.overflow = '';
  state.currentEditId = null;
  state.editorDraft = null;
  state.editorImage = null;
}

function syncEditorInputs() {
  const e = state.editorDraft;
  els.zoomRange.value = Math.round(e.zoom * 100);
  els.panXRange.value = e.panX;
  els.panYRange.value = e.panY;
  els.brightnessRange.value = e.brightness;
  els.contrastRange.value = e.contrast;
  els.saturationRange.value = e.saturation;
  els.grayscaleRange.value = e.grayscale;
  els.blurRange.value = e.blur;
  els.sharpnessRange.value = e.sharpness;
  els.useCustomOutputInput.checked = e.useCustomOutput;
  els.customWidthInput.value = e.customWidth;
  els.customHeightInput.value = e.customHeight;
  els.customKbInput.value = e.customKb;
  updateEditorOutputs();
  updateCustomFields();
}

function updateEditorOutputs() {
  els.zoomOutput.value = `${els.zoomRange.value}%`;
  els.panXOutput.value = els.panXRange.value;
  els.panYOutput.value = els.panYRange.value;
  els.brightnessOutput.value = `${els.brightnessRange.value}%`;
  els.contrastOutput.value = `${els.contrastRange.value}%`;
  els.saturationOutput.value = `${els.saturationRange.value}%`;
  els.grayscaleOutput.value = `${els.grayscaleRange.value}%`;
  els.blurOutput.value = `${els.blurRange.value}px`;
  els.sharpnessOutput.value = els.sharpnessRange.value;
}

function readEditorDraftFromInputs() {
  const e = state.editorDraft;
  e.zoom = clamp(els.zoomRange.value, 50, 300) / 100;
  e.panX = clamp(els.panXRange.value, -100, 100);
  e.panY = clamp(els.panYRange.value, -100, 100);
  e.brightness = clamp(els.brightnessRange.value, 0, 200);
  e.contrast = clamp(els.contrastRange.value, 0, 200);
  e.saturation = clamp(els.saturationRange.value, 0, 200);
  e.grayscale = clamp(els.grayscaleRange.value, 0, 100);
  e.blur = clamp(els.blurRange.value, 0, 10);
  e.sharpness = clamp(els.sharpnessRange.value, 0, 5);
  e.useCustomOutput = els.useCustomOutputInput.checked;
  e.customWidth = clamp(els.customWidthInput.value, 1, 8000);
  e.customHeight = clamp(els.customHeightInput.value, 1, 8000);
  e.customKb = clamp(els.customKbInput.value, 5, 5000);
}

async function renderEditorPreview() {
  if (!state.editorImage || !state.editorDraft) return;
  readEditorDraftFromInputs();
  updateEditorOutputs();
  const bulk = getBulkSettings();
  const width = state.editorDraft.useCustomOutput ? state.editorDraft.customWidth : bulk.width;
  const height = state.editorDraft.useCustomOutput ? state.editorDraft.customHeight : bulk.height;
  const maxPreview = 900;
  const previewScale = Math.min(1, maxPreview / Math.max(width, height));
  els.editorCanvas.width = Math.max(1, Math.round(width * previewScale));
  els.editorCanvas.height = Math.max(1, Math.round(height * previewScale));
  const ctx = els.editorCanvas.getContext('2d', { willReadFrequently: state.editorDraft.sharpness > 0 });
  const previewEdit = { ...state.editorDraft, sharpness: state.editorDraft.sharpness };
  drawTransformedImage(ctx, state.editorImage, els.editorCanvas.width, els.editorCanvas.height, bulk.fit, bulk.background, bulk.transparent, previewEdit);
}

function updateCustomFields() {
  const disabled = !els.useCustomOutputInput.checked;
  els.customWidthInput.disabled = disabled;
  els.customHeightInput.disabled = disabled;
  els.customKbInput.disabled = disabled;
}

function mutateEditor(mutator) {
  if (!state.editorDraft) return;
  mutator(state.editorDraft);
  syncEditorInputs();
  renderEditorPreview();
}

function resetCurrentEdit() {
  if (!state.editorDraft) return;
  const bulk = getBulkSettings();
  state.editorDraft = { ...defaultEdit(), customWidth: bulk.width, customHeight: bulk.height, customKb: bulk.targetKb };
  syncEditorInputs();
  renderEditorPreview();
}

function saveCurrentEdit() {
  const item = state.items.find((entry) => entry.id === state.currentEditId);
  if (!item || !state.editorDraft) return;
  readEditorDraftFromInputs();
  item.edit = JSON.parse(JSON.stringify(state.editorDraft));
  clearResults();
  renderQueue();
  closeEditor();
  showToast('Manual edit saved for this photo.', 'success');
}

function bindRange(id) {
  els[id].addEventListener('input', () => {
    updateEditorOutputs();
    renderEditorPreview();
  });
}

els.choosePhotosBtn.addEventListener('click', () => els.fileInput.click());
els.chooseFolderBtn.addEventListener('click', () => els.folderInput.click());
els.fileInput.addEventListener('change', (event) => addFiles(event.target.files));
els.folderInput.addEventListener('change', (event) => addFiles(event.target.files));
els.dropZone.addEventListener('dragover', (event) => { event.preventDefault(); els.dropZone.classList.add('is-dragging'); });
els.dropZone.addEventListener('dragleave', () => els.dropZone.classList.remove('is-dragging'));
els.dropZone.addEventListener('drop', (event) => { event.preventDefault(); els.dropZone.classList.remove('is-dragging'); addFiles(event.dataTransfer.files); });

els.backgroundColorInput.addEventListener('input', syncColorFromPicker);
els.backgroundHexInput.addEventListener('input', syncColorFromHex);
els.formatSelect.addEventListener('change', updateFormatState);
els.resetSettingsBtn.addEventListener('click', resetBulkSettings);
els.widthInput.addEventListener('input', () => {
  if (els.lockRatioInput.checked) els.heightInput.value = Math.max(1, Math.round(Number(els.widthInput.value) / state.originalRatio));
});
els.heightInput.addEventListener('input', () => {
  if (els.lockRatioInput.checked) els.widthInput.value = Math.max(1, Math.round(Number(els.heightInput.value) * state.originalRatio));
});
els.lockRatioInput.addEventListener('change', () => { state.originalRatio = Math.max(.0001, Number(els.widthInput.value) / Math.max(1, Number(els.heightInput.value))); });

els.photoGrid.addEventListener('click', handleGridClick);
els.photoGrid.addEventListener('change', handleGridChange);
els.searchInput.addEventListener('input', renderQueue);
els.selectAllBtn.addEventListener('click', toggleSelectAll);
els.removeSelectedBtn.addEventListener('click', removeSelected);
els.clearAllBtn.addEventListener('click', clearAll);
els.processBtn.addEventListener('click', processAll);
els.downloadZipBtn.addEventListener('click', downloadZip);
els.downloadIndividualBtn.addEventListener('click', downloadIndividually);

els.closeEditorBtn.addEventListener('click', closeEditor);
els.cancelEditBtn.addEventListener('click', closeEditor);
els.editorModal.addEventListener('click', (event) => { if (event.target === els.editorModal) closeEditor(); });
els.saveEditBtn.addEventListener('click', saveCurrentEdit);
els.resetEditBtn.addEventListener('click', resetCurrentEdit);
els.rotateLeftBtn.addEventListener('click', () => mutateEditor((e) => { e.rotation = (e.rotation - 90) % 360; }));
els.rotateRightBtn.addEventListener('click', () => mutateEditor((e) => { e.rotation = (e.rotation + 90) % 360; }));
els.flipHBtn.addEventListener('click', () => mutateEditor((e) => { e.flipH *= -1; }));
els.flipVBtn.addEventListener('click', () => mutateEditor((e) => { e.flipV *= -1; }));
['zoomRange','panXRange','panYRange','brightnessRange','contrastRange','saturationRange','grayscaleRange','blurRange','sharpnessRange'].forEach(bindRange);
els.useCustomOutputInput.addEventListener('change', () => { updateCustomFields(); renderEditorPreview(); });
[els.customWidthInput, els.customHeightInput, els.customKbInput].forEach((input) => input.addEventListener('input', renderEditorPreview));
document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && !els.editorModal.classList.contains('is-hidden')) closeEditor(); });
window.addEventListener('beforeunload', () => { state.items.forEach((item) => URL.revokeObjectURL(item.previewUrl)); state.resultUrls.forEach((url) => URL.revokeObjectURL(url)); });

updateFormatState();
renderQueue();
